Native Oberon System 3 Release 2.3.6 (Stand-alone)

Please refer to install.txt for instructions on installing Native Oberon.
For a minimal stand-alone installation you need install.txt, rawrite.exe
and oberon0.dsk from this directory.

See http://www.oberon.ethz.ch/native/ for more information.

